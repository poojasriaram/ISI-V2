const s="/assets/about-hero-bg-CIUF0q2F.jpg";export{s as c};
