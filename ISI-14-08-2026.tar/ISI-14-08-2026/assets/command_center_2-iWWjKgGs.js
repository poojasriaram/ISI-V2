const c="/assets/command_center_2-Bk_o8qe1.jpg";export{c};
