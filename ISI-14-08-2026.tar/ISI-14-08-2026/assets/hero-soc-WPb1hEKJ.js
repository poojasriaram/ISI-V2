const s="/assets/hero-soc-CXtqHPST.jpg";export{s as h};
