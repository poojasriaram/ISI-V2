const c="/assets/command_center_4-BGNWUfgV.jpg";export{c};
