const t="/assets/command_center_1-BvVomRS9.jpg";export{t};
