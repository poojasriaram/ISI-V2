const s="/assets/verticals-surveillance-CVXljQ13.jpg";export{s as c};
