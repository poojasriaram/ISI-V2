const c="/assets/command_center_3-Cu9xahn_.jpg";export{c};
