const e="/assets/hero-ai-driven-DvRHlKL_.jpg";export{e as h};
