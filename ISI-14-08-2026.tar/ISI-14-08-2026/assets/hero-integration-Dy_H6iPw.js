const o="/assets/hero-integration-CWXl4sNo.jpg";export{o as h};
