const c="/assets/command_center_5-C4_T4l4c.jpg";export{c};
